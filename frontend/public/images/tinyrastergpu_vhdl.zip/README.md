# TinyRasterGPU (VHDL, Vivado-ready)

Minimal 2D GPU-like rasterizer for FPGA.
- 320x240 RGB565 framebuffer in BRAM
- VGA 640x480@60 via 2x pixel-doubling
- Commands: CLEAR, FILL_RECT, TRI_FILL
- Simple Wishbone-lite style registers

## Files
- `dpram.vhd` — dual-port BRAM (inferred)
- `vga_timing_640x480.vhd` — VGA timing
- `tinygpu_regs.vhd` — MMIO register block
- `tinygpu_raster.vhd` — rasterizer
- `fb_reader.vhd` — framebuffer read & RGB565 split
- `tinyrastergpu_top.vhd` — top-level core
- `tinyrastergpu_basys3.vhd` — Basys3 wrapper + demo sequencer
- `clk_wiz_25m_stub.vhd` — **stub** of Clocking Wizard (replace with real IP)
- `Basys3.xdc` — sample constraints
- `tb_tinyrastergpu_ppm.vhd` — testbench dumping `fb_dump.ppm`

## Vivado (HW)
1. Create project, add VHDL sources (except testbench if not needed).
2. Generate **Clocking Wizard** named `clk_wiz_25m` producing ~25.175 MHz `clk_pix` and a system clock `clk_sys`.
3. Set top: `tinyrastergpu_basys3` and apply `Basys3.xdc` (or adapt for your board).
4. Synthesize → Implement → Bitstream → Program.
5. VGA should show a red rectangle and a green triangle.

## Vivado (Sim)
1. Add all VHDL + `tb_tinyrastergpu_ppm.vhd`.
2. Set simulation top: `tb_tinyrastergpu_ppm`.
3. Run Behavioral Simulation; a `fb_dump.ppm` will be created.

## Notes
- The stub `clk_wiz_25m_stub.vhd` is only to satisfy elaboration; it does **not** generate 25 MHz. Replace with the genuine IP for hardware.
- Target devices with ≥ ~1.3 Mbit BRAM (e.g., Artix-7 35T+).
- This design is pedagogical; throughput is modest (pixel-by-pixel). Extend with DMA/FIFO, span-line, or tilers for speed.
